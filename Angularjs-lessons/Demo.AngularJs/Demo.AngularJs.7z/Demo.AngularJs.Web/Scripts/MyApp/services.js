﻿'use strict';

angular.module('demo.services', [])
    .factory('api', ['$http', function ($resource) {
        //see this example: http://stackoverflow.com/questions/17328724/requesting-example-for-angular-js-http-or-resource-post-and-transformrequest
        var url = 'http://api.rottentomatoes.com/api/public/v1.0/lists/movies/box_office.json?:apiKey';
        //[{ title: 'test', links: { self: 'http://www.google.com' }, posters: { thumbnail: 'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTw3d_AuZa3EEzi1MNYTNz1caF62yFFCfKtbxTPuc-pfSsSnN-8' } }];
        var api = $resource(url, { apikey: '@apiKey' }, { search: { method: 'GET', isArray: true } });
        return api;
    }]);