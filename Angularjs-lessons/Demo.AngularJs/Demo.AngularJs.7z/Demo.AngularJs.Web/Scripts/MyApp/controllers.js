﻿'use strict';

angular.module('demo.controllers', ['demo.services'])
    .controller('main', ['$scope','api', function ($scope, api) {
        $scope.movies = api.search({ apikey: 'vbp26ua7wx3yzd4429nz7e5a' });
    }]);